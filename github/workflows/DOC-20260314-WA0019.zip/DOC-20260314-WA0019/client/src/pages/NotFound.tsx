import { useLocation } from 'wouter';

export default function NotFound() {
  const [, setLocation] = useLocation();

  const handleGoHome = () => {
    setLocation('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
      <div className="text-center max-w-md mx-4">
        <div className="mb-6">
          <i className="fas fa-exclamation-circle text-6xl" style={{ color: 'oklch(0.577 0.245 27.325)' }}></i>
        </div>
        <h1 className="text-5xl font-bold mb-2" style={{ fontFamily: "'Poppins', sans-serif" }}>404</h1>
        <h2 className="text-2xl font-semibold mb-4">Página não encontrada</h2>
        <p className="text-muted-foreground mb-8">
          Desculpe, a página que você está procurando não existe ou foi removida.
        </p>
        <button
          onClick={handleGoHome}
          className="btn-primary inline-flex items-center gap-2"
        >
          <i className="fas fa-home"></i>
          Voltar para Home
        </button>
      </div>
    </div>
  );
}
