import { useState, useEffect, useCallback } from 'react';

/**
 * Hook customizado para gerenciar persistência de dados com localStorage
 * Sincroniza automaticamente estado com localStorage
 * 
 * @param key - Chave no localStorage
 * @param initialValue - Valor inicial se não houver dados salvos
 * @returns [value, setValue] - Estado e função para atualizar
 */
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  // Estado para armazenar o valor
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      // Tenta recuperar do localStorage
      const item = window.localStorage.getItem(key);
      if (item) {
        return JSON.parse(item);
      }
      return initialValue;
    } catch (error) {
      console.error(`Erro ao carregar ${key} do localStorage:`, error);
      return initialValue;
    }
  });

  // Função para atualizar o valor e salvar no localStorage
  const setValue = useCallback((value: T | ((val: T) => T)) => {
    try {
      // Permite passar uma função como em useState
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Atualiza o estado
      setStoredValue(valueToStore);
      
      // Salva no localStorage
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
      
      // Dispara evento customizado para sincronizar entre abas
      window.dispatchEvent(
        new StorageEvent('local-storage', {
          key,
          newValue: JSON.stringify(valueToStore),
          oldValue: null,
          storageArea: window.localStorage,
          url: window.location.href
        })
      );
    } catch (error) {
      console.error(`Erro ao salvar ${key} no localStorage:`, error);
    }
  }, [key, storedValue]);

  // Sincroniza com mudanças em outras abas/janelas
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue) {
        try {
          setStoredValue(JSON.parse(e.newValue));
        } catch (error) {
          console.error(`Erro ao sincronizar ${key}:`, error);
        }
      }
    };

    // Listener para eventos de storage (mudanças em outras abas)
    window.addEventListener('storage', handleStorageChange);
    
    // Listener para evento customizado (mudanças na mesma aba)
    window.addEventListener('local-storage', handleStorageChange as EventListener);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('local-storage', handleStorageChange as EventListener);
    };
  }, [key]);

  return [storedValue, setValue];
}

/**
 * Função utilitária para limpar dados do localStorage
 */
export function clearLocalStorage(keys?: string[]): void {
  try {
    if (keys) {
      keys.forEach(key => window.localStorage.removeItem(key));
    } else {
      window.localStorage.clear();
    }
  } catch (error) {
    console.error('Erro ao limpar localStorage:', error);
  }
}

/**
 * Função utilitária para exportar todos os dados como JSON
 */
export function exportDataAsJSON(filename: string = 'backup-gastos.json'): void {
  try {
    const data = {
      incomes: JSON.parse(window.localStorage.getItem('incomes') || '[]'),
      expenses: JSON.parse(window.localStorage.getItem('expenses') || '[]'),
      budgets: JSON.parse(window.localStorage.getItem('budgets') || '[]'),
      exportDate: new Date().toISOString()
    };

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2)));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  } catch (error) {
    console.error('Erro ao exportar dados:', error);
    throw error;
  }
}

/**
 * Função utilitária para importar dados do JSON
 */
export function importDataFromJSON(file: File): Promise<{ incomes: any[]; expenses: any[]; budgets: any[] }> {
  return new Promise((resolve, reject) => {
    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          
          // Valida estrutura básica
          if (!data.incomes || !data.expenses || !data.budgets) {
            throw new Error('Arquivo JSON inválido. Estrutura esperada: { incomes, expenses, budgets }');
          }

          // Salva no localStorage
          window.localStorage.setItem('incomes', JSON.stringify(data.incomes));
          window.localStorage.setItem('expenses', JSON.stringify(data.expenses));
          window.localStorage.setItem('budgets', JSON.stringify(data.budgets));

          resolve(data);
        } catch (error) {
          reject(new Error(`Erro ao processar arquivo: ${error}`));
        }
      };
      reader.onerror = () => reject(new Error('Erro ao ler arquivo'));
      reader.readAsText(file);
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Função para obter tamanho do localStorage em KB
 */
export function getLocalStorageSize(): number {
  try {
    let total = 0;
    for (let key in window.localStorage) {
      if (window.localStorage.hasOwnProperty(key)) {
        total += window.localStorage[key].length + key.length;
      }
    }
    return Math.round(total / 1024 * 100) / 100; // Retorna em KB
  } catch (error) {
    console.error('Erro ao calcular tamanho do localStorage:', error);
    return 0;
  }
}
