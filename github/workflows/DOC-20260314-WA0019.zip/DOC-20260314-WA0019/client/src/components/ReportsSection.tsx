import React, { useEffect, useRef } from 'react';
import { Expense, Income } from '@/pages/Dashboard';
import Chart from 'chart.js/auto';

interface ReportsSectionProps {
  expenses: Expense[];
  incomes: Income[];
  totalIncomes: number;
  totalExpenses: number;
  balance: number;
  onExportPDF: () => void;
  onExportExcel: () => void;
  onExportData: () => void;
  onRestoreData: (event: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
  onResetData: () => void;
}

const CATEGORIES = [
  'Transporte',
  'Alimentação',
  'Lazer',
  'Moradia',
  'Saúde',
  'Educação',
  'Outros'
];

export default function ReportsSection({
  expenses,
  incomes,
  totalIncomes,
  totalExpenses,
  balance,
  onExportPDF,
  onExportExcel,
  onExportData,
  onRestoreData,
  onResetData
}: ReportsSectionProps) {
  const pieChartRef = useRef<HTMLCanvasElement>(null);
  const lineChartRef = useRef<HTMLCanvasElement>(null);
  const pieChartInstance = useRef<Chart | null>(null);
  const lineChartInstance = useRef<Chart | null>(null);

  // Prepare data for pie chart
  const categoryData = CATEGORIES.map(category => ({
    category,
    total: expenses.filter(e => e.category === category).reduce((sum, e) => sum + e.value, 0)
  })).filter(item => item.total > 0);

  // Prepare data for line chart (daily balance)
  const getDailyBalance = () => {
    const dailyData: { [key: string]: number } = {};
    let runningBalance = 0;

    // Sort all transactions by date
    const allTransactions = [
      ...incomes.map(i => ({ date: i.date, amount: i.value, type: 'income' })),
      ...expenses.map(e => ({ date: e.date, amount: -e.value, type: 'expense' }))
    ].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    allTransactions.forEach(transaction => {
      runningBalance += transaction.amount;
      const dateStr = new Date(transaction.date).toLocaleDateString('pt-BR');
      dailyData[dateStr] = runningBalance;
    });

    return Object.entries(dailyData).map(([date, balance]) => ({ date, balance }));
  };

  const dailyBalance = getDailyBalance();

  // Pie Chart
  useEffect(() => {
    if (pieChartRef.current && categoryData.length > 0) {
      const ctx = pieChartRef.current.getContext('2d');
      if (!ctx) return;

      if (pieChartInstance.current) {
        pieChartInstance.current.destroy();
      }

      pieChartInstance.current = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: categoryData.map(d => d.category),
          datasets: [{
            data: categoryData.map(d => d.total),
            backgroundColor: [
              'oklch(0.65 0.2 259.815)',
              'oklch(0.56 0.2 259.815)',
              'oklch(0.47 0.2 259.815)',
              'oklch(0.38 0.2 259.815)',
              'oklch(0.29 0.2 259.815)',
              'oklch(0.7 0.2 70)',
              'oklch(0.577 0.245 27.325)'
            ],
            borderColor: 'oklch(1 0 0)',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      });
    }

    return () => {
      if (pieChartInstance.current) {
        pieChartInstance.current.destroy();
      }
    };
  }, [categoryData]);

  // Line Chart
  useEffect(() => {
    if (lineChartRef.current && dailyBalance.length > 0) {
      const ctx = lineChartRef.current.getContext('2d');
      if (!ctx) return;

      if (lineChartInstance.current) {
        lineChartInstance.current.destroy();
      }

      lineChartInstance.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: dailyBalance.map(d => d.date),
          datasets: [{
            label: 'Saldo Diário',
            data: dailyBalance.map(d => d.balance),
            borderColor: 'oklch(0.56 0.2 259.815)',
            backgroundColor: 'oklch(0.56 0.2 259.815 / 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointRadius: 4,
            pointBackgroundColor: 'oklch(0.56 0.2 259.815)',
            pointBorderColor: 'oklch(1 0 0)',
            pointBorderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          plugins: {
            legend: {
              display: true
            }
          },
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }

    return () => {
      if (lineChartInstance.current) {
        lineChartInstance.current.destroy();
      }
    };
  }, [dailyBalance]);

  return (
    <div className="space-y-6">
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">Distribuição de Despesas</h3>
          {categoryData.length > 0 ? (
            <canvas ref={pieChartRef}></canvas>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>Nenhuma despesa para exibir</p>
            </div>
          )}
        </div>

        {/* Line Chart */}
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">Evolução do Saldo</h3>
          {dailyBalance.length > 0 ? (
            <canvas ref={lineChartRef}></canvas>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>Nenhum dado para exibir</p>
            </div>
          )}
        </div>
      </div>

      {/* Summary Table */}
      <div className="card-summary">
        <h3 className="text-xl font-bold mb-4">Resumo Detalhado</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-medium">Descrição</th>
                <th className="text-right py-3 px-4 font-medium">Valor</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border hover:bg-muted">
                <td className="py-3 px-4">Total de Receitas</td>
                <td className="text-right py-3 px-4 font-medium" style={{ color: 'oklch(0.65 0.2 142.495)' }}>
                  R$ {totalIncomes.toFixed(2)}
                </td>
              </tr>
              <tr className="border-b border-border hover:bg-muted">
                <td className="py-3 px-4">Total de Despesas</td>
                <td className="text-right py-3 px-4 font-medium" style={{ color: 'oklch(0.577 0.245 27.325)' }}>
                  R$ {totalExpenses.toFixed(2)}
                </td>
              </tr>
              <tr className="bg-muted hover:bg-accent">
                <td className="py-3 px-4 font-bold">Saldo Final</td>
                <td className="text-right py-3 px-4 font-bold" style={{ color: balance >= 0 ? 'oklch(0.65 0.2 142.495)' : 'oklch(0.577 0.245 27.325)' }}>
                  R$ {balance.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Category Breakdown */}
        <div className="mt-6 pt-6 border-t border-border">
          <h4 className="font-bold mb-3">Despesas por Categoria</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {CATEGORIES.map(category => {
              const total = expenses.filter(e => e.category === category).reduce((sum, e) => sum + e.value, 0);
              return total > 0 ? (
                <div key={category} className="flex justify-between p-3 bg-muted rounded-lg">
                  <span>{category}</span>
                  <span className="font-medium">R$ {total.toFixed(2)}</span>
                </div>
              ) : null;
            })}
          </div>
        </div>
      </div>

      {/* Export and Backup */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export */}
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">Exportar Relatório</h3>

          <div className="space-y-3">
            <button
              onClick={onExportPDF}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <i className="fas fa-file-pdf"></i>
              Exportar para PDF
            </button>

            <button
              onClick={onExportExcel}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <i className="fas fa-file-excel"></i>
              Exportar para Excel
            </button>
          </div>
        </div>

        {/* Backup */}
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">Backup & Restore</h3>

          <div className="space-y-3">
            <button
              onClick={onExportData}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <i className="fas fa-download"></i>
              Exportar Dados (JSON)
            </button>

            <label className="btn-primary w-full flex items-center justify-center gap-2 cursor-pointer">
              <i className="fas fa-upload"></i>
              Restaurar Dados
              <input
                type="file"
                accept=".json"
                onChange={onRestoreData}
                className="hidden"
              />
            </label>

            <button
              onClick={onResetData}
              className="btn-secondary w-full flex items-center justify-center gap-2"
              style={{ color: 'oklch(0.577 0.245 27.325)' }}
            >
              <i className="fas fa-trash"></i>
              Resetar Todos os Dados
            </button>
          </div>

          <p className="text-xs text-muted-foreground mt-4">
            <i className="fas fa-info-circle mr-2"></i>
            Exporte seus dados em JSON para backup. Você pode restaurá-los posteriormente. Cuidado ao resetar - esta ação não pode ser desfeita!
          </p>
        </div>
      </div>
    </div>
  );
}
