import React from 'react';

interface TabNavigationProps {
  activeTab: string;
  onTabChange: (tab: 'income' | 'expenses' | 'calculator' | 'reports' | 'budget') => void;
}

export default function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  const tabs = [
    { id: 'income', label: 'Receitas', icon: 'fa-plus-circle' },
    { id: 'expenses', label: 'Despesas', icon: 'fa-minus-circle' },
    { id: 'calculator', label: 'Calculadora', icon: 'fa-calculator' },
    { id: 'reports', label: 'Relatórios', icon: 'fa-file-pdf' },
    { id: 'budget', label: 'Orçamento', icon: 'fa-bullseye' }
  ];

  return (
    <div className="flex flex-wrap gap-2 border-b border-border">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id as any)}
          className={`tab-button flex items-center gap-2 ${
            activeTab === tab.id ? 'active' : 'text-muted-foreground'
          }`}
        >
          <i className={`fas ${tab.icon}`}></i>
          {tab.label}
        </button>
      ))}
    </div>
  );
}
