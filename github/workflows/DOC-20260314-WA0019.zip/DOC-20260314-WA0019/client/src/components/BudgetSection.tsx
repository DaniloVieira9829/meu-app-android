import React, { useState } from 'react';
import { Budget, Expense } from '@/pages/Dashboard';
import { toast } from 'sonner';

interface BudgetSectionProps {
  budgets: Budget[];
  expenses: Expense[];
  onUpdateBudgets: (budgets: Budget[]) => void;
}

const CATEGORIES = [
  'Transporte',
  'Alimentação',
  'Lazer',
  'Moradia',
  'Saúde',
  'Educação',
  'Outros'
];

export default function BudgetSection({
  budgets,
  expenses,
  onUpdateBudgets
}: BudgetSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState('Alimentação');
  const [budgetValue, setBudgetValue] = useState('');
  const [editingCategory, setEditingCategory] = useState<string | null>(null);

  const handleSetBudget = (e: React.FormEvent) => {
    e.preventDefault();

    if (!budgetValue || parseFloat(budgetValue) <= 0) {
      toast.error('Digite um valor válido');
      return;
    }

    const newBudgets = budgets.filter(b => b.category !== selectedCategory);
    newBudgets.push({
      category: selectedCategory,
      limit: parseFloat(budgetValue)
    });

    onUpdateBudgets(newBudgets);
    toast.success(`Orçamento de ${selectedCategory} definido!`);
    setBudgetValue('');
    setEditingCategory(null);
  };

  const handleEditBudget = (category: string, limit: number) => {
    setEditingCategory(category);
    setSelectedCategory(category);
    setBudgetValue(limit.toString());
  };

  const handleDeleteBudget = (category: string) => {
    onUpdateBudgets(budgets.filter(b => b.category !== category));
    toast.success('Orçamento removido!');
  };

  const getCategoryExpenses = (category: string) => {
    return expenses.filter(e => e.category === category).reduce((sum, e) => sum + e.value, 0);
  };

  const getBudgetStatus = (category: string, limit: number) => {
    const spent = getCategoryExpenses(category);
    const percentage = (spent / limit) * 100;

    if (percentage >= 100) {
      return { status: 'exceeded', percentage, spent };
    } else if (percentage >= 80) {
      return { status: 'warning', percentage, spent };
    } else {
      return { status: 'ok', percentage, spent };
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Form */}
      <div className="lg:col-span-1">
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">
            {editingCategory ? `Editar Orçamento: ${editingCategory}` : 'Definir Orçamento'}
          </h3>

          <form onSubmit={handleSetBudget} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Categoria</label>
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setEditingCategory(null);
                  setBudgetValue('');
                }}
                className="input-field"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Limite Mensal (R$) *</label>
              <input
                type="number"
                value={budgetValue}
                onChange={(e) => setBudgetValue(e.target.value)}
                placeholder="0.00"
                step="0.01"
                className="input-field"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                className="btn-primary flex-1"
              >
                {editingCategory ? 'Atualizar' : 'Definir'}
              </button>
              {editingCategory && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingCategory(null);
                    setBudgetValue('');
                  }}
                  className="btn-secondary flex-1"
                >
                  Cancelar
                </button>
              )}
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-border">
            <h4 className="font-medium mb-3">Informações</h4>
            <p className="text-sm text-muted-foreground">
              <i className="fas fa-lightbulb mr-2" style={{ color: 'oklch(0.7 0.2 70)' }}></i>
              Defina orçamentos para cada categoria e receba alertas quando estiver próximo do limite.
            </p>
          </div>
        </div>
      </div>

      {/* Budget List */}
      <div className="lg:col-span-2">
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">Orçamentos Definidos ({budgets.length})</h3>

          {budgets.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <i className="fas fa-inbox text-4xl mb-4 block opacity-50"></i>
              <p>Nenhum orçamento definido ainda</p>
            </div>
          ) : (
            <div className="space-y-4">
              {budgets.map((budget) => {
                const { status, percentage, spent } = getBudgetStatus(budget.category, budget.limit);
                const remaining = budget.limit - spent;

                return (
                  <div
                    key={budget.category}
                    className="p-4 bg-muted rounded-lg"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-bold text-lg">{budget.category}</h4>
                        <p className="text-sm text-muted-foreground">
                          Gasto: <span className="font-medium">R$ {spent.toFixed(2)}</span> de{' '}
                          <span className="font-medium">R$ {budget.limit.toFixed(2)}</span>
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditBudget(budget.category, budget.limit)}
                          className="p-2 hover:bg-background rounded transition-colors"
                          title="Editar"
                        >
                          <i className="fas fa-edit text-blue-500"></i>
                        </button>

                        <button
                          onClick={() => handleDeleteBudget(budget.category)}
                          className="p-2 hover:bg-background rounded transition-colors"
                          title="Deletar"
                        >
                          <i className="fas fa-trash text-red-500"></i>
                        </button>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-2">
                      <div className="w-full bg-background rounded-full h-3">
                        <div
                          className="h-3 rounded-full transition-all duration-300"
                          style={{
                            width: `${Math.min(percentage, 100)}%`,
                            backgroundColor:
                              status === 'exceeded'
                                ? 'oklch(0.577 0.245 27.325)'
                                : status === 'warning'
                                  ? 'oklch(0.7 0.2 70)'
                                  : 'oklch(0.65 0.2 142.495)'
                          }}
                        ></div>
                      </div>
                    </div>

                    {/* Status */}
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-medium">{percentage.toFixed(1)}%</span>

                      {status === 'exceeded' && (
                        <span className="flex items-center gap-1 text-red-600 font-medium">
                          <i className="fas fa-exclamation-circle"></i>
                          Orçamento excedido em R$ {Math.abs(remaining).toFixed(2)}
                        </span>
                      )}
                      {status === 'warning' && (
                        <span className="flex items-center gap-1 text-yellow-600 font-medium">
                          <i className="fas fa-exclamation-triangle"></i>
                          Faltam R$ {remaining.toFixed(2)}
                        </span>
                      )}
                      {status === 'ok' && (
                        <span className="flex items-center gap-1 text-green-600 font-medium">
                          <i className="fas fa-check-circle"></i>
                          Faltam R$ {remaining.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
